$(document).ready(function() {

    $('#nestable').nestable({
        group: 1
    });

    $('#nestable2').nestable();

});